package com.everis.streetfullstacker.repository;


import java.io.Serializable;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Table;




/**
 * Tabla: StreetFullStacker * 
 *
 */
@Entity
@Table(name = "StreetFullStacker")
public class Story implements Serializable{

	/** SERIAL ID */
	private static final long serialVersionUID = 1L;
	
 	/**Story ID**/
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
 	private int storyId;
	
	@Column(name="description")
	private String description;
	
	
	//@ManyToOne
	//@JoinColumn(name="questionId", nullable=false)
	//Set <Questions> question;


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


    

	//public Set<Questions> getQuestion() {
		//return question;
	//}


	//public void setQuestion(Set<Questions> question) {
		//this.question = question;
	//}


	public int getStoryId() {
		return storyId;
	}


	public void setStoryId(int storyId) {
		this.storyId = storyId;
	}
	
	@Override
	public String toString() {
		return "Story [storyId=" + storyId + ", description=" + description + ", question=" +  "]";
	}

	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((description == null) ? 0 : description.hashCode());
	
		result = prime * result + storyId;
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Story other = (Story) obj;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
	
		if (storyId != other.storyId)
			return false;
		return true;
	}
	


}