package com.everis.streetfullstacker.repository;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.validator.constraints.Length;

/**
 * 
 * @author Grupo A
 *
 */
@Table
@Entity(name="Rol")
public class Role implements Serializable {

	/**
	 * Serial UID version
	 */
	private static final long serialVersionUID = 6839913599035139803L;

	/**
	 * Owns attributes of the class role
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int roleId;
	
	@Column(name="rolename",nullable=false)
	@Length(min=3, max=25)
	private String rolename;
	
	/**
	 * 1:N relationship on Hibernate with role class	
	 */
	@OneToMany(mappedBy="role")
	private Set<User> users;
	
	
	/**
	 * Getters and setters
	 * @return
	 */
	public int getRoleId() {
		return roleId;
	}

	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}

	public String getRolename() {
		return rolename;
	}
    
	public void setRolename(String rolename) {
		this.rolename = rolename;
	}

	
	
	
	public Set<User> getUsers() {
		return users;
	}

	public void setUsers(Set<User> users) {
		this.users = users;
	}
   /**
    * ToString() method
    */
	@Override
	public String toString() {
		return "Role [roleId=" + roleId + ", rolename=" + rolename + ", users=" + users + "]";
	}
  /**
   * hashCode and equals method
   */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + roleId;
		result = prime * result + ((rolename == null) ? 0 : rolename.hashCode());
		result = prime * result + ((users == null) ? 0 : users.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Role other = (Role) obj;
		if (roleId != other.roleId)
			return false;
		if (rolename == null) {
			if (other.rolename != null)
				return false;
		} else if (!rolename.equals(other.rolename))
			return false;
		if (users == null) {
			if (other.users != null)
				return false;
		} else if (!users.equals(other.users))
			return false;
		return true;
	}

	
	
	
	
			
}
