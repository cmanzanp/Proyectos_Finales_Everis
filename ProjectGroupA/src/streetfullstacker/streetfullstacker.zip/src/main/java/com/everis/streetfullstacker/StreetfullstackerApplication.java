package com.everis.streetfullstacker;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.everis.streetfullstacker.repository.Role;
import com.everis.streetfullstacker.repository.User;

@SpringBootApplication
public class StreetfullstackerApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(StreetfullstackerApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		
	}

}
