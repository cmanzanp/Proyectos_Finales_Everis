package com.everis.streetfullstacker.services;

import java.util.List;
import java.util.Optional;

import com.everis.streetfullstacker.repository.Question;

public interface QuestionManagementServiceI {

	/**
	 * Método que inserta una pregunta nueva en la base de datos
	 * 
	 * @param entity
	 */
	public void insert(final Question entity);

	/**
	 * Método que consulta todas las preguntas en la base de datos
	 * 
	 * @return List<Question>
	 */
	public List<Question> searchAll();

	/**
	 * Método que consulta una pregunta en la base de datos a partir de su ID
	 * 
	 * @param id
	 */
	public Optional<Question> searchById(final Long id);

	/**
	 * Método que borra una pregunta en la base de datos a partir de su ID
	 * 
	 * @param id
	 */
	public void delete(final Long id);

	/**
	 * Método que actualiza los datos de una pregunta en la base de datos
	 * 
	 * @param entity
	 */
	public void update(final Question entity);
}
